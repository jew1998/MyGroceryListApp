/*
 * Service settings
 */
var GroceryListStudents_settings = {
    "database_url": "https://api.appery.io/rest/1/db",
    "database_id": "571fa732e4b06624d2ffccb1"
}

/*
 * Services
 */

var GroceryListStudents_groceryList_list_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var GroceryListStudents_groceryList_delete_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList/{_id}',
    'dataType': 'json',
    'type': 'delete',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var GroceryListStudents_groceryList_query_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var GroceryListStudents_groceryList_create_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList',
    'dataType': 'json',
    'type': 'post',
    'contentType': 'application/json',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/json"
        },
        "parameters": {},
        "body": {
            "acl": {
                "*": {
                    "write": true,
                    "read": true
                }
            }
        }
    }
});

var GroceryListStudents_groceryList_update_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList/{_id}',
    'dataType': 'json',
    'type': 'put',
    'contentType': 'application/json',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/json"
        },
        "parameters": {},
        "body": {
            "acl": {
                "*": {
                    "write": true,
                    "read": true
                }
            }
        }
    }
});

var GroceryListStudents_groceryList_read_service = new Apperyio.RestService({
    'url': '{database_url}/collections/groceryList/{_id}',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': GroceryListStudents_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});