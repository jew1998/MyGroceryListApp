function storagePush(arrayName, value){
    var arr = Apperyio.storage[arrayName].get();
    return Apperyio.storage[arrayName].update("$["+ arr.length +"]", value);
}
